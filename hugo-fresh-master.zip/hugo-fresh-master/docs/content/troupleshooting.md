---
title: Troubleshooting
sidebar: true
sidebarlogo: fresh-white
include_footer: false
---

## Hugo extended

If you see `error: failed to transform resource: TOCSS: failed to transform "style.sass"` when attempting to run your `hugo server`, make sure you have the extended version of Hugo installed!
